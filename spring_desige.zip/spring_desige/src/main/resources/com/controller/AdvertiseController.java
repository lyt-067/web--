package controller;

import javax.servlet.http.HttpServletRequest;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import po.Advertise;
import serviceinterface.AdvertiseService;

@Controller
@RequestMapping("advertise")
public class AdvertiseController {
	@Autowired
	private AdvertiseService advertiseService;
	
	@RequestMapping("/toAddAdvertise")
	public String toAddAdvertise(Model model){
		model.addAttribute("advertise", new Advertise());
		System.out.println("aaaaaaaaaaaaaaaaaaaa");
		return "admin/addAdvertise";
	}
	@RequestMapping("/addAdvertise")
	public String AddAdvertise(@ModelAttribute Advertise advertise,HttpServletRequest request){
		System.out.println("bbbbbbbbbbbbbbbb");
		return advertiseService.addAdvertise(advertise, request);
	}
	@RequestMapping("/deleteAdvertiseSelect")
	public String deleteAdvertiseSelect(Model model) {
		return advertiseService.deleteAdvertiseSelect(model);
	}
	@RequestMapping("/selectAAdvertise")
	public String selectAAdvertise(Model model, Integer ad_id) {
		return advertiseService.selectAAdvertise(model, ad_id);
	}
	@RequestMapping("/deleteAdvertise")
	public String deleteAdvertise(Integer ad_id) {
		return advertiseService.deleteAdvertise(ad_id);
	}
}
