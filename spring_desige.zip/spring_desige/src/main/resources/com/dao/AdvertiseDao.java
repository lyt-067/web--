package dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import po.Advertise;

@Repository("advertiseDao")
@Mapper
public interface AdvertiseDao {
//public List<Advertise> selectadvertise();
public List<Advertise> deleteAdvertiseSelect();
public Advertise selectAAdvertise(int ad_id);
public int adadvertise(Advertise advertise);
public int deleteAdvertise(int ad_id);
}
