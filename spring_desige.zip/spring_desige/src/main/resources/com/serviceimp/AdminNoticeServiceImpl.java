package serviceimp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import dao.AdminNoticeDao;
import po.Notice;
import serviceinterface.AdminNoticeService;
@Service("adminNoticeService")
@Transactional
public class AdminNoticeServiceImpl implements AdminNoticeService{
	@Autowired
	private AdminNoticeDao adminNoticeDao;
	public String addNotice(Notice notice) {
		adminNoticeDao.addNotice(notice);
		return "forward:/adminNotice/deleteNoticeSelect";
	}
	public String deleteNoticeSelect(Model model) {
		model.addAttribute("allNotices", adminNoticeDao.deleteNoticeSelect());
		return "admin/deleteNoticeSelect";
	}
	public String selectANotice(Model model, Integer notice_id) {
		model.addAttribute("notice", adminNoticeDao.selectANotice(notice_id));
		return "admin/noticeDetail";
	}
	public String deleteNotice(Integer notice_id) {
		adminNoticeDao.deleteNotice(notice_id);
		return "forward:/adminNotice/deleteNoticeSelect";
	}

}
