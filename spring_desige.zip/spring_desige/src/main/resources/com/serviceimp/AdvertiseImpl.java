package serviceimp;

import java.io.File;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.internal.lang.annotation.ajcDeclareAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import dao.AdvertiseDao;
import po.Advertise;
import serviceinterface.AdvertiseService;
import util.MyUtil;

@Service("advertiseService")
@Transactional
public class AdvertiseImpl implements AdvertiseService {
	@Autowired
	private AdvertiseDao advertiseDao;

	public String addAdvertise(Advertise advertise,HttpServletRequest request) {
		// ��ֹ�ļ�������
		String newFileName = "";
		String fileName = advertise.getAdUpImage().getOriginalFilename();
		// ѡ�����ļ�
		if (fileName.length() > 0) {
			String realpath = request.getServletContext().getRealPath("/advertises");
			System.out.println(realpath);
			// ʵ���ļ��ϴ�
			String fileType = fileName.substring(fileName.lastIndexOf('.'));
			// ��ֹ�ļ�������
			newFileName = MyUtil.getStringID() + fileType;
			advertise.setAdimage(newFileName);
			File targetFile = new File(realpath, newFileName);
			if (!targetFile.exists()) {
				targetFile.mkdirs();
				System.out.println("�ɹ������ļ���");
			}
			// �ϴ�
			try {
				advertise.getAdUpImage().transferTo(targetFile);
				System.out.println("�ļ��ϴ��ɹ�" + realpath);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		advertiseDao.adadvertise(advertise);
		return "forward:/advertise/deleteAdvertiseSelect";
	}

	@Override
	public String deleteAdvertiseSelect(Model model) {
		model.addAttribute("advertises", advertiseDao.deleteAdvertiseSelect());
		return "admin/deleteAdvertiseSelect";
	}

	@Override
	public String selectAAdvertise(Model model, Integer ad_id) {
		model.addAttribute("advertise", advertiseDao.selectAAdvertise(ad_id));
		return "admin/advertisedetail";
	}

	@Override
	public String deleteAdvertise(Integer ad_id) {
		advertiseDao.deleteAdvertise(ad_id);
		return "forward:/advertise/deleteAdvertiseSelect";
	}

}
