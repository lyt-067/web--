package serviceimp;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.omg.CORBA.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import dao.AdminNoticeDao;
import dao.AdminTypeDao;
import dao.IndexDao;
import po.Buser;
import po.Goods;
import po.Notice;
import serviceinterface.IndexService;

@Service("indexService")
@Transactional
public class IndexServiceImpl implements IndexService{
	@Autowired
	private IndexDao indexDao;
	@Autowired
	private AdminTypeDao adminTypeDao;
	@Autowired
	private AdminNoticeDao adminNoticeDao;
	public String before(Model model, HttpSession session, Goods goods) {
		session.setAttribute("goodsType", adminTypeDao.selectGoodsType());
		model.addAttribute("salelist", indexDao.getSaleOrder());
		model.addAttribute("focuslist", indexDao.getFocusOrder());
		model.addAttribute("noticelist", indexDao.selectNotice());
		//��ѯ���
		model.addAttribute("advertiselist", indexDao.selectAdvertise());
		if(goods.getGoods_id() == null) 
			goods.setGoods_id(0);
		model.addAttribute("lastedlist", indexDao.getLastedGoods(goods));
		return "before/index";
	}

	public String toRegister(Model model) {
		model.addAttribute("rbuser", new Buser());
		return "before/register";
	}

	public String toLogin(Model model) {
		model.addAttribute("lbuser", new Buser());
		return "before/login";
	}

	public String goodsDetail(Model model, Integer goods_id) {
		Goods goods = indexDao.selectGoodsById(goods_id);
		model.addAttribute("goods", goods);
		return "before/goodsdetail";
	}

	public String selectANotice(Model model, Integer notice_id) {
		Notice notice = adminNoticeDao.selectANotice(notice_id);
		model.addAttribute("notice", notice);
		return "admin/noticeDetail";
	}

	public String search(Model model, String mykey) {
		List<Goods> list = indexDao.search(mykey);
		model.addAttribute("searchlist", list);
		return "before/searchResult";
	}
	
}
