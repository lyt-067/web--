package serviceimp;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import dao.AdminDao;
import dao.AdminTypeDao;
import po.Auser;

@Service("adminService")
@Transactional
public class AdminServiceImp implements serviceinterface.IAdminSer {

	@Autowired
	private AdminDao adminDao;
	@Autowired
	private AdminTypeDao adminTypeDao;
	
	public String login(Auser auser, Model model, HttpSession session) {
		if(adminDao.login(auser) != null && adminDao.login(auser).size() > 0) {
			session.setAttribute("auser", auser);
			//������Ʒ���޸���Ʒҳ��ʹ��
			session.setAttribute("goodsType", adminTypeDao.selectGoodsType());
System.out.println(auser);	
			return "admin/main";
		}
System.out.println(auser);
		model.addAttribute("msg", "�û������������");
		return "admin/login";
	}

}
