package serviceinterface;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import po.Advertise;
import po.Notice;

public interface AdvertiseService {
	public String addAdvertise(Advertise advertise,HttpServletRequest request);
	public String deleteAdvertiseSelect(Model model);
	public String selectAAdvertise(Model model, Integer ad_id);
	public String deleteAdvertise(Integer ad_id);
}
