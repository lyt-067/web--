package serviceinterface;

import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import po.Auser;

public interface IAdminSer {
	public String login(Auser auser, Model model, HttpSession session);
}
