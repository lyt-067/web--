package po;

public class Buser {
	private int buser_id;
	private String bname;
	private String bpwd;
	private String bemail;

	public int getBuser_id() {
		return buser_id;
	}

	public void setBuser_id(int buser_id) {
		this.buser_id = buser_id;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	public String getBpwd() {
		return bpwd;
	}

	public void setBpwd(String bpwd) {
		this.bpwd = bpwd;
	}

	public String getBemail() {
		return bemail;
	}

	public void setBemail(String bemail) {
		this.bemail = bemail;
	}

}
