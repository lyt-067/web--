package po;

public class OrderBase {
	private Integer orderbase_id;
	private Integer buser_id;
	private Double amount;
	private Integer status;
	private String orderdate;

	public Integer getOrderbase_id() {
		return orderbase_id;
	}

	public void setOrderbase_id(Integer orderbase_id) {
		this.orderbase_id = orderbase_id;
	}

	public Integer getBuser_id() {
		return buser_id;
	}

	public void setBuser_id(Integer buser_id) {
		this.buser_id = buser_id;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(String orderdate) {
		this.orderdate = orderdate;
	}

}
