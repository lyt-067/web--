package po;

public class GoodsType {
	private Integer goodstype_id;
	private String typename;

	public Integer getGoodstype_id() {
		return goodstype_id;
	}

	public void setGoodstype_id(Integer goodstype_id) {
		this.goodstype_id = goodstype_id;
	}

	public String getTypename() {
		return typename;
	}

	public void setTypename(String typename) {
		this.typename = typename;
	}

}
