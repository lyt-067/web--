package po;

import org.springframework.web.multipart.MultipartFile;

public class Advertise {
	private int ad_id;
	private String adname;
	private String adcontext;
	private String adtime;
	private MultipartFile adUpImage;
	private String adimage;
	private int goodstype_id;

	public int getAd_id() {
		return ad_id;
	}

	public void setAd_id(int ad_id) {
		this.ad_id = ad_id;
	}

	public String getAdname() {
		return adname;
	}

	public void setAdname(String adname) {
		this.adname = adname;
	}

	public String getAdcontext() {
		return adcontext;
	}

	public void setAdcontext(String adcontext) {
		this.adcontext = adcontext;
	}
	

	public String getAdtime() {
		return adtime;
	}

	public void setAdtime(String adtime) {
		this.adtime = adtime;
	}

	

	public MultipartFile getAdUpImage() {
		return adUpImage;
	}

	public void setAdUpImage(MultipartFile adUpImage) {
		this.adUpImage = adUpImage;
	}

	public String getAdimage() {
		return adimage;
	}

	public void setAdimage(String adimage) {
		this.adimage = adimage;
	}

	public int getGoodstype_id() {
		return goodstype_id;
	}

	public void setGoodstype_id(int goodstype_id) {
		this.goodstype_id = goodstype_id;
	}

}
